import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { FileText, LogOut, Crown } from 'lucide-react';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <nav className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <Link to="/dashboard" className="flex-shrink-0 flex items-center gap-2">
              <div className="bg-red-600 text-white p-1.5 rounded-md">
                <FileText size={24} />
              </div>
              <span className="font-bold text-xl text-gray-900">PDF Master</span>
            </Link>
          </div>
          <div className="flex items-center space-x-4">
            {user ? (
              <>
                {user.role === 'admin' && (
                  <Link
                    to="/admin/dashboard"
                    className="text-sm font-medium text-gray-600 hover:text-gray-900"
                  >
                    Admin Dashboard
                  </Link>
                )}
                <Link
                  to="/pricing"
                  className="flex items-center gap-1 text-sm font-medium text-gray-600 hover:text-gray-900"
                >
                  <Crown size={16} className="text-yellow-500" />
                  {user.role === 'pro' ? 'Pro Plan' : 'Upgrade'}
                </Link>
                <div className="flex items-center gap-3 ml-4 pl-4 border-l border-gray-200">
                  <div className="flex flex-col items-end">
                    <span className="text-sm font-medium text-gray-900">{user.name}</span>
                    <span className="text-xs text-gray-500">
                      {user.role === 'pro' || user.role === 'admin' ? 'Unlimited' : `${user.usageCount}/5 used today`}
                    </span>
                  </div>
                  <img
                    className="h-8 w-8 rounded-full border border-gray-200"
                    src={user.picture || `https://ui-avatars.com/api/?name=${user.name}`}
                    alt={user.name}
                  />
                  <button
                    onClick={logout}
                    className="p-2 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100 transition-colors"
                    title="Logout"
                  >
                    <LogOut size={20} />
                  </button>
                </div>
              </>
            ) : (
              <>
                <Link
                  to="/admin/login"
                  className="text-sm font-medium text-gray-600 hover:text-gray-900"
                >
                  Admin
                </Link>
                <Link
                  to="/login"
                  className="inline-flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700"
                >
                  Log in
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
