import React, { useState, useCallback, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useDropzone } from 'react-dropzone';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';
import { File, Trash2, UploadCloud, Download, Loader2, Wrench } from 'lucide-react';

const toolConfig: Record<string, { title: string; desc: string; endpoint: string; multiple: boolean; implemented: boolean }> = {
  merge: {
    title: 'Merge PDF files',
    desc: 'Combine PDFs in the order you want with the easiest PDF merger available.',
    endpoint: '/api/pdf/merge',
    multiple: true,
    implemented: true,
  },
  split: {
    title: 'Split PDF file',
    desc: 'Separate one page or a whole set for easy conversion into independent PDF files.',
    endpoint: '/api/pdf/split',
    multiple: false,
    implemented: true,
  },
};

export default function ToolPage() {
  const { toolId } = useParams<{ toolId: string }>();
  const { user, loading, refreshUser } = useAuth();
  const navigate = useNavigate();
  const [files, setFiles] = useState<File[]>([]);
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resultUrl, setResultUrl] = useState<string | null>(null);

  useEffect(() => {
    if (!loading && !user) {
      navigate('/login');
    }
  }, [user, loading, navigate]);

  const config = toolId ? toolConfig[toolId] : null;

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setError(null);
    setResultUrl(null);
    if (config?.multiple) {
      setFiles((prev) => [...prev, ...acceptedFiles]);
    } else {
      setFiles([acceptedFiles[0]]);
    }
  }, [config]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
    },
    multiple: config?.multiple ?? false,
  } as any);

  const removeFile = (index: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const processFiles = async () => {
    if (!config || !config.implemented) return;
    if (files.length === 0) return;
    if (toolId === 'merge' && files.length < 2) {
      setError('Please select at least 2 files to merge.');
      return;
    }

    setProcessing(true);
    setError(null);

    const formData = new FormData();
    if (config.multiple) {
      files.forEach((file) => formData.append('files', file));
    } else {
      formData.append('file', files[0]);
    }

    try {
      const response = await axios.post(config.endpoint, formData, {
        withCredentials: true,
        responseType: 'blob',
      });

      const url = window.URL.createObjectURL(new Blob([response.data]));
      setResultUrl(url);
      await refreshUser(); // Update usage count
    } catch (err: any) {
      if (err.response && err.response.data && err.response.data instanceof Blob) {
        const text = await err.response.data.text();
        try {
          const json = JSON.parse(text);
          setError(json.error || 'An error occurred during processing.');
        } catch {
          setError('An error occurred during processing.');
        }
      } else {
        setError(err.message || 'An error occurred during processing.');
      }
    } finally {
      setProcessing(false);
    }
  };

  if (loading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600"></div>
      </div>
    );
  }

  if (!config) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
        <div className="flex justify-center mb-6">
          <div className="bg-gray-100 p-6 rounded-full">
            <Wrench size={64} className="text-gray-400" />
          </div>
        </div>
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Coming Soon</h1>
        <p className="text-xl text-gray-500 max-w-2xl mx-auto mb-8">
          The <strong>{toolId?.replace(/-/g, ' ')}</strong> tool is currently under development and will be available in a future update.
        </p>
        <button onClick={() => navigate('/dashboard')} className="inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-xl text-white bg-red-600 hover:bg-red-700 shadow-sm transition-all">
          Go back to Dashboard
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-10">
        <h1 className="text-4xl font-extrabold text-gray-900 sm:text-5xl">{config.title}</h1>
        <p className="mt-4 text-xl text-gray-500">{config.desc}</p>
      </div>

      {error && (
        <div className="mb-8 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 text-center">
          {error}
        </div>
      )}

      {resultUrl ? (
        <div className="bg-white p-12 rounded-2xl shadow-xl border border-gray-100 text-center flex flex-col items-center justify-center">
          <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mb-6">
            <Download size={48} className="text-green-600" />
          </div>
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Task completed successfully!</h2>
          <p className="text-gray-500 mb-8">Your document is ready to be downloaded.</p>
          <div className="flex gap-4">
            <a
              href={resultUrl}
              download={`${toolId}-result.pdf`}
              className="inline-flex items-center justify-center px-8 py-4 border border-transparent text-lg font-medium rounded-xl text-white bg-red-600 hover:bg-red-700 shadow-lg hover:shadow-xl transition-all"
            >
              Download PDF
            </a>
            <button
              onClick={() => {
                setResultUrl(null);
                setFiles([]);
              }}
              className="inline-flex items-center justify-center px-8 py-4 border-2 border-gray-200 text-lg font-medium rounded-xl text-gray-700 bg-white hover:bg-gray-50 transition-all"
            >
              Start over
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
          <div className="p-8">
            <div
              {...getRootProps()}
              className={`border-4 border-dashed rounded-xl p-12 text-center cursor-pointer transition-colors ${
                isDragActive ? 'border-red-500 bg-red-50' : 'border-gray-300 hover:border-red-400 hover:bg-gray-50'
              }`}
            >
              <input {...getInputProps()} />
              <UploadCloud size={64} className="mx-auto text-gray-400 mb-4" />
              <p className="text-2xl font-bold text-gray-700 mb-2">
                {isDragActive ? 'Drop files here' : 'Select PDF files'}
              </p>
              <p className="text-gray-500">or drop PDFs here</p>
            </div>

            {files.length > 0 && (
              <div className="mt-8">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Selected Files ({files.length})</h3>
                <ul className="space-y-3">
                  {files.map((file, index) => (
                    <li key={`${file.name}-${index}`} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200">
                      <div className="flex items-center">
                        <File className="text-red-500 mr-3" size={24} />
                        <span className="text-sm font-medium text-gray-900 truncate max-w-xs sm:max-w-md">
                          {file.name}
                        </span>
                      </div>
                      <button
                        onClick={() => removeFile(index)}
                        className="text-gray-400 hover:text-red-600 p-2 rounded-full hover:bg-red-50 transition-colors"
                      >
                        <Trash2 size={20} />
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <div className="bg-gray-50 px-8 py-6 border-t border-gray-200 flex justify-between items-center">
            <div className="text-sm text-gray-500">
              {user.role === 'free' && (
                <span className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-yellow-400"></span>
                  {5 - user.usageCount} free uses remaining today
                </span>
              )}
            </div>
            <button
              onClick={processFiles}
              disabled={files.length === 0 || processing}
              className={`inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-xl text-white shadow-sm transition-all ${
                files.length === 0 || processing
                  ? 'bg-gray-400 cursor-not-allowed'
                  : 'bg-red-600 hover:bg-red-700 hover:shadow-lg'
              }`}
            >
              {processing ? (
                <>
                  <Loader2 className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" />
                  Processing...
                </>
              ) : (
                config.title
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
