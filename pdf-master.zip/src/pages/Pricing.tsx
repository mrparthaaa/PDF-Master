import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Check, X, Loader2 } from 'lucide-react';
import axios from 'axios';

declare global {
  interface Window {
    Razorpay: any;
  }
}

const loadRazorpayScript = () => {
  return new Promise((resolve) => {
    if (window.Razorpay) {
      resolve(true);
      return;
    }
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.onload = () => {
      resolve(true);
    };
    script.onerror = () => {
      resolve(false);
    };
    document.body.appendChild(script);
  });
};

export default function Pricing() {
  const { user, refreshUser } = useAuth();
  const [loading, setLoading] = useState(false);

  const handleUpgrade = async () => {
    if (!user) {
      window.location.href = '/login';
      return;
    }

    setLoading(true);
    try {
      const isLoaded = await loadRazorpayScript();
      if (!isLoaded) {
        alert('Failed to load Razorpay SDK. Please check your internet connection.');
        setLoading(false);
        return;
      }

      // 1. Get Razorpay Key ID
      const { data: { key } } = await axios.get('/api/payment/key', { withCredentials: true });

      // 2. Create Order
      const { data: order } = await axios.post('/api/payment/create-order', { plan: 'monthly' }, { withCredentials: true });

      // 3. Open Razorpay Checkout
      const options = {
        key: key,
        amount: order.amount,
        currency: order.currency,
        name: 'PDF Master',
        description: 'Pro Plan Subscription',
        order_id: order.id,
        handler: async function (response: any) {
          try {
            // 4. Verify Payment
            await axios.post('/api/payment/verify', {
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
              plan: 'monthly'
            }, { withCredentials: true });

            await refreshUser();
            alert('Payment successful! You are now a Pro user.');
          } catch (error) {
            console.error('Payment verification failed:', error);
            alert('Payment verification failed. Please contact support.');
          }
        },
        prefill: {
          name: user.name,
          email: user.email,
        },
        theme: {
          color: '#DC2626',
        },
      };

      const rzp = new window.Razorpay(options);
      rzp.on('payment.failed', function (response: any) {
        console.error('Payment failed:', response.error);
        alert('Payment failed. Please try again.');
      });
      rzp.open();
    } catch (error: any) {
      console.error('Error initiating payment:', error);
      alert(error.response?.data?.error || 'Failed to initiate payment. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-gray-50 py-12 sm:py-16 lg:py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl lg:text-5xl">
            Simple, transparent pricing
          </h2>
          <p className="mt-4 text-xl text-gray-500">
            Choose the plan that best fits your needs.
          </p>
        </div>

        <div className="mt-16 space-y-12 lg:space-y-0 lg:grid lg:grid-cols-2 lg:gap-x-8">
          {/* Free Plan */}
          <div className="relative p-8 bg-white border border-gray-200 rounded-2xl shadow-sm flex flex-col">
            <div className="flex-1">
              <h3 className="text-xl font-semibold text-gray-900">Free</h3>
              <p className="mt-4 flex items-baseline text-gray-900">
                <span className="text-5xl font-extrabold tracking-tight">₹0</span>
                <span className="ml-1 text-xl font-semibold">/month</span>
              </p>
              <p className="mt-6 text-gray-500">
                Perfect for occasional use and basic PDF tasks.
              </p>

              <ul role="list" className="mt-6 space-y-6">
                <li className="flex">
                  <Check className="flex-shrink-0 w-6 h-6 text-green-500" aria-hidden="true" />
                  <span className="ml-3 text-gray-500">Access to all PDF tools</span>
                </li>
                <li className="flex">
                  <Check className="flex-shrink-0 w-6 h-6 text-green-500" aria-hidden="true" />
                  <span className="ml-3 text-gray-500">Up to 5 document processing per day</span>
                </li>
                <li className="flex">
                  <Check className="flex-shrink-0 w-6 h-6 text-green-500" aria-hidden="true" />
                  <span className="ml-3 text-gray-500">Standard processing speed</span>
                </li>
                <li className="flex">
                  <X className="flex-shrink-0 w-6 h-6 text-red-500" aria-hidden="true" />
                  <span className="ml-3 text-gray-500">No ads</span>
                </li>
                <li className="flex">
                  <X className="flex-shrink-0 w-6 h-6 text-red-500" aria-hidden="true" />
                  <span className="ml-3 text-gray-500">Priority customer support</span>
                </li>
              </ul>
            </div>

            <button
              disabled={user?.role === 'free'}
              className={`mt-8 block w-full py-3 px-6 border border-transparent rounded-md text-center font-medium ${
                user?.role === 'free'
                  ? 'bg-gray-100 text-gray-500 cursor-not-allowed'
                  : 'bg-red-50 text-red-700 hover:bg-red-100'
              }`}
            >
              {user?.role === 'free' ? 'Current Plan' : 'Downgrade to Free'}
            </button>
          </div>

          {/* Pro Plan */}
          <div className="relative p-8 bg-white border border-red-200 rounded-2xl shadow-xl flex flex-col ring-2 ring-red-600">
            <div className="absolute top-0 py-1.5 px-4 bg-red-600 rounded-full text-xs font-semibold uppercase tracking-wide text-white transform -translate-y-1/2">
              Most Popular
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-semibold text-gray-900">Pro</h3>
              <p className="mt-4 flex items-baseline text-gray-900">
                <span className="text-5xl font-extrabold tracking-tight">₹499</span>
                <span className="ml-1 text-xl font-semibold">/month</span>
              </p>
              <p className="mt-6 text-gray-500">
                For power users who need unlimited access and premium features.
              </p>

              <ul role="list" className="mt-6 space-y-6">
                <li className="flex">
                  <Check className="flex-shrink-0 w-6 h-6 text-green-500" aria-hidden="true" />
                  <span className="ml-3 text-gray-500">Access to all PDF tools</span>
                </li>
                <li className="flex">
                  <Check className="flex-shrink-0 w-6 h-6 text-green-500" aria-hidden="true" />
                  <span className="ml-3 text-gray-900 font-bold">Unlimited document processing</span>
                </li>
                <li className="flex">
                  <Check className="flex-shrink-0 w-6 h-6 text-green-500" aria-hidden="true" />
                  <span className="ml-3 text-gray-500">Fastest processing speed</span>
                </li>
                <li className="flex">
                  <Check className="flex-shrink-0 w-6 h-6 text-green-500" aria-hidden="true" />
                  <span className="ml-3 text-gray-500">Ad-free experience</span>
                </li>
                <li className="flex">
                  <Check className="flex-shrink-0 w-6 h-6 text-green-500" aria-hidden="true" />
                  <span className="ml-3 text-gray-500">Priority customer support</span>
                </li>
              </ul>
            </div>

            <button
              onClick={handleUpgrade}
              disabled={user?.role === 'pro' || loading}
              className={`mt-8 flex justify-center items-center w-full py-3 px-6 border border-transparent rounded-md text-center font-medium ${
                user?.role === 'pro'
                  ? 'bg-gray-100 text-gray-500 cursor-not-allowed'
                  : 'bg-red-600 text-white hover:bg-red-700 shadow-md'
              }`}
            >
              {loading ? (
                <Loader2 className="animate-spin h-5 w-5" />
              ) : user?.role === 'pro' ? (
                'Current Plan'
              ) : (
                'Upgrade to Pro'
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
