import React, { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  FilePlus, SplitSquareHorizontal, FileMinus, FileOutput, ArrowUpDown, RotateCw, RefreshCw, Copy, Scan,
  Minimize, HardDriveDownload, Wrench, Layers, Image, ScanText, FileSearch,
  FileText, Table, Presentation, Code, Book, Archive,
  Droplet, Eraser, Hash, LayoutTemplate, Type, Highlighter, PenTool, Hexagon, PenLine, Crop,
  Shield, Unlock, Key, Lock, EyeOff, GitCompare, Printer, CopyX,
  Combine, BrainCircuit, Languages, Database, FormInput, FileEdit
} from 'lucide-react';

const categories = [
  {
    name: 'ORGANIZE PDF',
    tools: [
      { id: 'merge', name: 'Merge PDF', icon: <Combine size={32} className="text-red-500" />, color: 'bg-red-50 border-red-100 hover:border-red-300' },
      { id: 'split', name: 'Split PDF', icon: <SplitSquareHorizontal size={32} className="text-orange-500" />, color: 'bg-orange-50 border-orange-100 hover:border-orange-300' },
      { id: 'remove-pages', name: 'Remove Pages', icon: <FileMinus size={32} className="text-red-500" />, color: 'bg-red-50 border-red-100 hover:border-red-300' },
      { id: 'extract-pages', name: 'Extract Pages', icon: <FileOutput size={32} className="text-blue-500" />, color: 'bg-blue-50 border-blue-100 hover:border-blue-300' },
      { id: 'reorder-pages', name: 'Reorder Pages', icon: <ArrowUpDown size={32} className="text-green-500" />, color: 'bg-green-50 border-green-100 hover:border-green-300' },
      { id: 'rotate-pages', name: 'Rotate Pages', icon: <RotateCw size={32} className="text-yellow-500" />, color: 'bg-yellow-50 border-yellow-100 hover:border-yellow-300' },
      { id: 'insert-pages', name: 'Insert Pages', icon: <FilePlus size={32} className="text-purple-500" />, color: 'bg-purple-50 border-purple-100 hover:border-purple-300' },
      { id: 'replace-pages', name: 'Replace Pages', icon: <RefreshCw size={32} className="text-teal-500" />, color: 'bg-teal-50 border-teal-100 hover:border-teal-300' },
      { id: 'duplicate-pages', name: 'Duplicate Pages', icon: <Copy size={32} className="text-indigo-500" />, color: 'bg-indigo-50 border-indigo-100 hover:border-indigo-300' },
      { id: 'scan-to-pdf', name: 'Scan to PDF', icon: <Scan size={32} className="text-gray-500" />, color: 'bg-gray-50 border-gray-200 hover:border-gray-400' },
    ]
  },
  {
    name: 'OPTIMIZE PDF',
    tools: [
      { id: 'compress', name: 'Compress PDF', icon: <Minimize size={32} className="text-green-500" />, color: 'bg-green-50 border-green-100 hover:border-green-300' },
      { id: 'reduce-size', name: 'Reduce File Size', icon: <HardDriveDownload size={32} className="text-green-600" />, color: 'bg-green-50 border-green-100 hover:border-green-300' },
      { id: 'repair', name: 'Repair PDF', icon: <Wrench size={32} className="text-gray-600" />, color: 'bg-gray-50 border-gray-200 hover:border-gray-400' },
      { id: 'flatten', name: 'Flatten PDF', icon: <Layers size={32} className="text-blue-500" />, color: 'bg-blue-50 border-blue-100 hover:border-blue-300' },
      { id: 'optimize-images', name: 'Optimize Images', icon: <Image size={32} className="text-pink-500" />, color: 'bg-pink-50 border-pink-100 hover:border-pink-300' },
      { id: 'ocr', name: 'OCR PDF', icon: <ScanText size={32} className="text-indigo-500" />, color: 'bg-indigo-50 border-indigo-100 hover:border-indigo-300' },
      { id: 'searchable', name: 'Convert to Searchable', icon: <FileSearch size={32} className="text-indigo-600" />, color: 'bg-indigo-50 border-indigo-100 hover:border-indigo-300' },
    ]
  },
  {
    name: 'CONVERT TO PDF',
    tools: [
      { id: 'jpg-to-pdf', name: 'JPG to PDF', icon: <Image size={32} className="text-yellow-500" />, color: 'bg-yellow-50 border-yellow-100 hover:border-yellow-300' },
      { id: 'png-to-pdf', name: 'PNG to PDF', icon: <Image size={32} className="text-yellow-600" />, color: 'bg-yellow-50 border-yellow-100 hover:border-yellow-300' },
      { id: 'word-to-pdf', name: 'Word to PDF', icon: <FileText size={32} className="text-blue-600" />, color: 'bg-blue-50 border-blue-100 hover:border-blue-300' },
      { id: 'excel-to-pdf', name: 'Excel to PDF', icon: <Table size={32} className="text-green-600" />, color: 'bg-green-50 border-green-100 hover:border-green-300' },
      { id: 'ppt-to-pdf', name: 'PowerPoint to PDF', icon: <Presentation size={32} className="text-orange-600" />, color: 'bg-orange-50 border-orange-100 hover:border-orange-300' },
      { id: 'html-to-pdf', name: 'HTML to PDF', icon: <Code size={32} className="text-gray-700" />, color: 'bg-gray-50 border-gray-200 hover:border-gray-400' },
      { id: 'text-to-pdf', name: 'Text to PDF', icon: <FileText size={32} className="text-gray-500" />, color: 'bg-gray-50 border-gray-200 hover:border-gray-400' },
      { id: 'epub-to-pdf', name: 'EPUB to PDF', icon: <Book size={32} className="text-purple-600" />, color: 'bg-purple-50 border-purple-100 hover:border-purple-300' },
    ]
  },
  {
    name: 'CONVERT FROM PDF',
    tools: [
      { id: 'pdf-to-jpg', name: 'PDF to JPG', icon: <Image size={32} className="text-yellow-500" />, color: 'bg-yellow-50 border-yellow-100 hover:border-yellow-300' },
      { id: 'pdf-to-png', name: 'PDF to PNG', icon: <Image size={32} className="text-yellow-600" />, color: 'bg-yellow-50 border-yellow-100 hover:border-yellow-300' },
      { id: 'pdf-to-word', name: 'PDF to Word', icon: <FileText size={32} className="text-blue-600" />, color: 'bg-blue-50 border-blue-100 hover:border-blue-300' },
      { id: 'pdf-to-excel', name: 'PDF to Excel', icon: <Table size={32} className="text-green-600" />, color: 'bg-green-50 border-green-100 hover:border-green-300' },
      { id: 'pdf-to-ppt', name: 'PDF to PowerPoint', icon: <Presentation size={32} className="text-orange-600" />, color: 'bg-orange-50 border-orange-100 hover:border-orange-300' },
      { id: 'pdf-to-text', name: 'PDF to Text', icon: <FileText size={32} className="text-gray-500" />, color: 'bg-gray-50 border-gray-200 hover:border-gray-400' },
      { id: 'pdf-to-html', name: 'PDF to HTML', icon: <Code size={32} className="text-gray-700" />, color: 'bg-gray-50 border-gray-200 hover:border-gray-400' },
      { id: 'pdf-to-pdfa', name: 'PDF to PDF/A', icon: <Archive size={32} className="text-teal-600" />, color: 'bg-teal-50 border-teal-100 hover:border-teal-300' },
    ]
  },
  {
    name: 'EDIT PDF',
    tools: [
      { id: 'add-watermark', name: 'Add Watermark', icon: <Droplet size={32} className="text-blue-400" />, color: 'bg-blue-50 border-blue-100 hover:border-blue-300' },
      { id: 'remove-watermark', name: 'Remove Watermark', icon: <Eraser size={32} className="text-pink-400" />, color: 'bg-pink-50 border-pink-100 hover:border-pink-300' },
      { id: 'add-page-numbers', name: 'Add Page Numbers', icon: <Hash size={32} className="text-gray-500" />, color: 'bg-gray-50 border-gray-200 hover:border-gray-400' },
      { id: 'header-footer', name: 'Header & Footer', icon: <LayoutTemplate size={32} className="text-indigo-400" />, color: 'bg-indigo-50 border-indigo-100 hover:border-indigo-300' },
      { id: 'edit-text', name: 'Edit Text', icon: <Type size={32} className="text-gray-700" />, color: 'bg-gray-50 border-gray-200 hover:border-gray-400' },
      { id: 'highlight', name: 'Highlight Text', icon: <Highlighter size={32} className="text-yellow-400" />, color: 'bg-yellow-50 border-yellow-100 hover:border-yellow-300' },
      { id: 'draw', name: 'Draw/Annotate', icon: <PenTool size={32} className="text-red-400" />, color: 'bg-red-50 border-red-100 hover:border-red-300' },
      { id: 'shapes', name: 'Add Shapes', icon: <Hexagon size={32} className="text-purple-400" />, color: 'bg-purple-50 border-purple-100 hover:border-purple-300' },
      { id: 'signature', name: 'Add Signature', icon: <PenLine size={32} className="text-blue-500" />, color: 'bg-blue-50 border-blue-100 hover:border-blue-300' },
      { id: 'crop', name: 'Crop PDF', icon: <Crop size={32} className="text-green-500" />, color: 'bg-green-50 border-green-100 hover:border-green-300' },
    ]
  },
  {
    name: 'PDF SECURITY',
    tools: [
      { id: 'protect', name: 'Protect PDF', icon: <Shield size={32} className="text-red-500" />, color: 'bg-red-50 border-red-100 hover:border-red-300' },
      { id: 'unlock', name: 'Unlock PDF', icon: <Unlock size={32} className="text-green-500" />, color: 'bg-green-50 border-green-100 hover:border-green-300' },
      { id: 'remove-password', name: 'Remove Password', icon: <Key size={32} className="text-yellow-500" />, color: 'bg-yellow-50 border-yellow-100 hover:border-yellow-300' },
      { id: 'encrypt', name: 'Encrypt PDF', icon: <Lock size={32} className="text-purple-500" />, color: 'bg-purple-50 border-purple-100 hover:border-purple-300' },
      { id: 'decrypt', name: 'Decrypt PDF', icon: <Unlock size={32} className="text-teal-500" />, color: 'bg-teal-50 border-teal-100 hover:border-teal-300' },
      { id: 'redact', name: 'Redact PDF', icon: <EyeOff size={32} className="text-gray-800" />, color: 'bg-gray-100 border-gray-300 hover:border-gray-500' },
      { id: 'compare', name: 'Compare PDF', icon: <GitCompare size={32} className="text-blue-500" />, color: 'bg-blue-50 border-blue-100 hover:border-blue-300' },
      { id: 'lock-printing', name: 'Lock Printing', icon: <Printer size={32} className="text-orange-500" />, color: 'bg-orange-50 border-orange-100 hover:border-orange-300' },
      { id: 'restrict-copying', name: 'Restrict Copying', icon: <CopyX size={32} className="text-pink-500" />, color: 'bg-pink-50 border-pink-100 hover:border-pink-300' },
    ]
  },
  {
    name: 'ADVANCED / PRO',
    tools: [
      { id: 'batch-processing', name: 'Batch Processing', icon: <Layers size={32} className="text-indigo-600" />, color: 'bg-indigo-50 border-indigo-200 hover:border-indigo-400' },
      { id: 'bulk-merge', name: 'Bulk Merge', icon: <Combine size={32} className="text-red-600" />, color: 'bg-red-50 border-red-200 hover:border-red-400' },
      { id: 'bulk-compress', name: 'Bulk Compress', icon: <Minimize size={32} className="text-green-600" />, color: 'bg-green-50 border-green-200 hover:border-green-400' },
      { id: 'ai-summary', name: 'AI Document Summary', icon: <BrainCircuit size={32} className="text-purple-600" />, color: 'bg-purple-50 border-purple-200 hover:border-purple-400' },
      { id: 'ai-translate', name: 'AI Translate PDF', icon: <Languages size={32} className="text-blue-600" />, color: 'bg-blue-50 border-blue-200 hover:border-blue-400' },
      { id: 'ai-extract', name: 'AI Extract Data', icon: <Database size={32} className="text-teal-600" />, color: 'bg-teal-50 border-teal-200 hover:border-teal-400' },
      { id: 'form-creator', name: 'PDF Form Creator', icon: <FormInput size={32} className="text-orange-600" />, color: 'bg-orange-50 border-orange-200 hover:border-orange-400' },
      { id: 'fill-form', name: 'Fill PDF Form', icon: <FileEdit size={32} className="text-yellow-600" />, color: 'bg-yellow-50 border-yellow-200 hover:border-yellow-400' },
      { id: 'scanned-to-editable', name: 'Scanned to Editable', icon: <ScanText size={32} className="text-pink-600" />, color: 'bg-pink-50 border-pink-200 hover:border-pink-400' },
    ]
  }
];

export default function Dashboard() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) {
      navigate('/login');
    }
  }, [user, loading, navigate]);

  if (loading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-extrabold text-gray-900 sm:text-5xl sm:tracking-tight lg:text-6xl">
          Every tool you need to work with PDFs in one place
        </h1>
        <p className="max-w-xl mt-5 mx-auto text-xl text-gray-500">
          Every tool you need to use PDFs, at your fingertips. All are 100% FREE and easy to use!
          Merge, split, compress, convert, rotate, unlock and watermark PDFs with just a few clicks.
        </p>
      </div>

      <div className="space-y-16">
        {categories.map((category) => (
          <div key={category.name}>
            <h2 className="text-2xl font-bold text-gray-900 mb-6 border-b pb-2">{category.name}</h2>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
              {category.tools.map((tool) => (
                <Link
                  key={tool.id}
                  to={`/tool/${tool.id}`}
                  className={`flex flex-col items-center text-center p-4 rounded-xl border-2 transition-all duration-200 transform hover:-translate-y-1 hover:shadow-md ${tool.color}`}
                >
                  <div className="mb-3 p-3 bg-white rounded-full shadow-sm">
                    {tool.icon}
                  </div>
                  <h3 className="text-sm font-bold text-gray-900">{tool.name}</h3>
                </Link>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
