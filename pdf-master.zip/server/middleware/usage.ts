import { Response, NextFunction } from 'express';
import { AuthRequest } from './auth.js';
import { isSameDay } from 'date-fns';

export const checkUsageLimit = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const user = req.user;
    if (!user) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    // Check subscription expiry
    if (user.role === 'pro' && user.subscriptionExpiry && new Date() > user.subscriptionExpiry) {
      user.role = 'free';
      await user.save();
    }

    if (user.role === 'pro' || user.role === 'admin') {
      return next();
    }

    const today = new Date();
    if (!isSameDay(user.lastUsageDate, today)) {
      user.usageCount = 0;
      user.lastUsageDate = today;
    }

    if (user.usageCount >= 5) {
      return res.status(403).json({ error: 'Daily usage limit reached. Upgrade to Pro for unlimited access.' });
    }

    user.usageCount += 1;
    await user.save();

    next();
  } catch (error) {
    return res.status(500).json({ error: 'Internal server error while checking usage limit' });
  }
};
