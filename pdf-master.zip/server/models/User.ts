import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  googleId: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  picture: { type: String },
  role: { type: String, enum: ['free', 'pro', 'admin'], default: 'free' },
  usageCount: { type: Number, default: 0 },
  lastUsageDate: { type: Date, default: Date.now },
  subscriptionExpiry: { type: Date, default: null },
  paymentHistory: [
    {
      paymentId: String,
      orderId: String,
      amount: Number,
      date: { type: Date, default: Date.now },
      plan: String
    }
  ],
  createdAt: { type: Date, default: Date.now }
});

export const User = mongoose.model('User', userSchema);
