import express from 'express';
import Razorpay from 'razorpay';
import crypto from 'crypto';
import { authenticate, AuthRequest } from '../middleware/auth.js';
import { User } from '../models/User.js';
import dotenv from 'dotenv';

dotenv.config();

const router = express.Router();

let razorpayInstance: Razorpay | null = null;

const getRazorpay = () => {
  if (!razorpayInstance) {
    if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
      console.warn('Razorpay keys are missing. Payment features will not work.');
      return null;
    }
    razorpayInstance = new Razorpay({
      key_id: process.env.RAZORPAY_KEY_ID,
      key_secret: process.env.RAZORPAY_KEY_SECRET,
    });
  }
  return razorpayInstance;
};

router.get('/key', authenticate, (req, res) => {
  res.json({ key: process.env.RAZORPAY_KEY_ID });
});

router.post('/create-order', authenticate, async (req: AuthRequest, res) => {
  try {
    const rzp = getRazorpay();
    if (!rzp) {
      return res.status(500).json({ error: 'Payment gateway not configured' });
    }

    const { plan } = req.body; // 'monthly' or 'yearly'
    let amount = 0;

    if (plan === 'monthly') {
      amount = 499 * 100; // ₹499 in paise
    } else if (plan === 'yearly') {
      amount = 4999 * 100; // ₹4999 in paise
    } else {
      return res.status(400).json({ error: 'Invalid plan selected' });
    }

    const options = {
      amount,
      currency: 'INR',
      receipt: `receipt_${req.user?._id}_${Date.now()}`,
    };

    const order = await rzp.orders.create(options);
    res.json(order);
  } catch (error) {
    console.error('Error creating order:', error);
    res.status(500).json({ error: 'Failed to create order' });
  }
});

router.post('/verify', authenticate, async (req: AuthRequest, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, plan } = req.body;
    const secret = process.env.RAZORPAY_KEY_SECRET;

    if (!secret) {
      return res.status(500).json({ error: 'Payment gateway not configured' });
    }

    const body = razorpay_order_id + '|' + razorpay_payment_id;
    const expectedSignature = crypto
      .createHmac('sha256', secret)
      .update(body.toString())
      .digest('hex');

    const isAuthentic = expectedSignature === razorpay_signature;

    if (isAuthentic) {
      const user = await User.findById(req.user?._id);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Calculate expiry date
      const expiryDate = new Date();
      if (plan === 'monthly') {
        expiryDate.setMonth(expiryDate.getMonth() + 1);
      } else if (plan === 'yearly') {
        expiryDate.setFullYear(expiryDate.getFullYear() + 1);
      }

      user.role = 'pro';
      user.subscriptionExpiry = expiryDate;
      user.paymentHistory.push({
        paymentId: razorpay_payment_id,
        orderId: razorpay_order_id,
        amount: plan === 'monthly' ? 499 : 4999,
        plan: plan
      });

      await user.save();

      res.json({ success: true, message: 'Payment verified successfully' });
    } else {
      res.status(400).json({ success: false, error: 'Invalid signature' });
    }
  } catch (error) {
    console.error('Error verifying payment:', error);
    res.status(500).json({ error: 'Payment verification failed' });
  }
});

export default router;
