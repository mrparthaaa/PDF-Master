import express from 'express';
import multer from 'multer';
import { PDFDocument } from 'pdf-lib';
import { authenticate, AuthRequest } from '../middleware/auth.js';
import { checkUsageLimit } from '../middleware/usage.js';

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage() });

router.post('/merge', authenticate, checkUsageLimit, upload.array('files', 10), async (req: AuthRequest, res) => {
  try {
    const files = req.files as Express.Multer.File[];
    if (!files || files.length < 2) {
      return res.status(400).json({ error: 'Please upload at least 2 PDF files to merge.' });
    }

    const mergedPdf = await PDFDocument.create();

    for (const file of files) {
      const pdf = await PDFDocument.load(file.buffer);
      const copiedPages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
      copiedPages.forEach((page) => mergedPdf.addPage(page));
    }

    const mergedPdfBytes = await mergedPdf.save();

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="merged.pdf"');
    res.send(Buffer.from(mergedPdfBytes));
  } catch (error) {
    console.error('Error merging PDFs:', error);
    res.status(500).json({ error: 'Failed to merge PDFs.' });
  }
});

router.post('/split', authenticate, checkUsageLimit, upload.single('file'), async (req: AuthRequest, res) => {
  try {
    const file = req.file;
    if (!file) {
      return res.status(400).json({ error: 'Please upload a PDF file to split.' });
    }

    const pdf = await PDFDocument.load(file.buffer);
    const pages = pdf.getPageIndices();

    // For simplicity, we'll just extract the first page as an example.
    // A real implementation would accept ranges and return a zip file.
    const splitPdf = await PDFDocument.create();
    const [copiedPage] = await splitPdf.copyPages(pdf, [0]);
    splitPdf.addPage(copiedPage);

    const splitPdfBytes = await splitPdf.save();

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="split.pdf"');
    res.send(Buffer.from(splitPdfBytes));
  } catch (error) {
    console.error('Error splitting PDF:', error);
    res.status(500).json({ error: 'Failed to split PDF.' });
  }
});

export default router;
