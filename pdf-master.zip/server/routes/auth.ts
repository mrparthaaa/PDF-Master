import express from 'express';
import passport from 'passport';
import jwt from 'jsonwebtoken';
import { authenticate, AuthRequest } from '../middleware/auth.js';
import { User } from '../models/User.js';
import dotenv from 'dotenv';

dotenv.config();

const router = express.Router();

router.get('/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

router.get(
  '/google/callback',
  passport.authenticate('google', { session: false, failureRedirect: '/login' }),
  (req, res) => {
    const user = req.user as any;
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET || 'fallback_secret', {
      expiresIn: '7d',
    });

    res.cookie('token', token, {
      httpOnly: true,
      secure: true,
      sameSite: 'none',
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    });

    res.redirect(`${process.env.APP_URL}/dashboard`);
  }
);

router.get('/me', authenticate, async (req: AuthRequest, res) => {
  try {
    const user = await User.findById(req.user?._id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Check subscription expiry
    if (user.role === 'pro' && user.subscriptionExpiry && new Date() > user.subscriptionExpiry) {
      user.role = 'free';
      await user.save();
    }

    res.json(user);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch user' });
  }
});

router.post('/logout', (req, res) => {
  res.clearCookie('token', {
    httpOnly: true,
    secure: true,
    sameSite: 'none',
  });
  res.json({ message: 'Logged out successfully' });
});

router.post('/admin/login', async (req, res) => {
  const { loginId, password } = req.body;

  if (loginId === 'PARTHA123' && password === 'Partha#226') {
    // Check if admin user exists, if not create one
    let adminUser = await User.findOne({ email: 'admin@pdfmaster.com' });
    
    if (!adminUser) {
      adminUser = await User.create({
        googleId: 'admin-local',
        name: 'Admin',
        email: 'admin@pdfmaster.com',
        role: 'admin',
      });
    }

    const token = jwt.sign({ id: adminUser._id }, process.env.JWT_SECRET || 'fallback_secret', {
      expiresIn: '1d',
    });

    res.cookie('token', token, {
      httpOnly: true,
      secure: true,
      sameSite: 'none',
      maxAge: 24 * 60 * 60 * 1000, // 1 day
    });

    res.json({ message: 'Admin login successful' });
  } else {
    res.status(401).json({ error: 'Invalid admin credentials' });
  }
});

router.get('/admin/users', authenticate, async (req: AuthRequest, res) => {
  try {
    if (req.user?.role !== 'admin') {
      return res.status(403).json({ error: 'Admin access required' });
    }
    const users = await User.find().sort({ createdAt: -1 });
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

export default router;
